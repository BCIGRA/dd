import { Connection, PublicKey } from '@solana/web3.js';
import { LOOKUP_TABLE_CACHE, MAINNET_PROGRAM_ID, Percent, RAYDIUM_MAINNET, TxVersion } from '@raydium-io/raydium-sdk';

export const API_ENDPOINT = "https://solana--mainnet.datahub.figment.io/apikey/ad6da50b8226303a433659af7d47c84c";
export const connection = new Connection(API_ENDPOINT, 'confirmed');
export const PROGRAMIDS = MAINNET_PROGRAM_ID;
export const RAYDIUM_MAINNET_API = RAYDIUM_MAINNET;
export const makeTxVersion = TxVersion.V0;
export const addLookupTableInfo = LOOKUP_TABLE_CACHE;
export const validatorPublicKey = new PublicKey('CCJvSp69FCR6YHkn2Vf9ehbUazXri8N7hUrgS1b3dKE');

// Define color variables
const Reset = '\x1b[0m';
const FgBlue = '\x1b[34m';

export const config = {
    outMint: "So11111111111111111111111111111111111111112",
    outDecimal: 9,
    amounts: ['0.25', '0.21', '0.2', '0.17', '0.1', '0.05', '0.007', '0.005'],
    slippage: new Percent(1, 100), // Slippage 1%
    profitThreshold: 1, // Minimum profit threshold
    priceImpactThreshold: 0.02, // Maximum price impact threshold
    units: 1000000,
    microLamports: 1,
    fee: 0.0001
};

export const spinner = {
    start: (text: string) => console.log(`${text}`),
    succeed: (text: string) => console.log(`${text}`),
    fail: (text: string) => console.log(`${text}`),
    warn: (text: string) => console.log(`${text}`),
    info: (text: string) => console.log(`${text}`),
    text: "",
    stop: () => { },
};

spinner.info(`${FgBlue}[${Reset}RPC${FgBlue}]${Reset} RPC: ${API_ENDPOINT}`);