import { PublicKey, Keypair, AddressLookupTableAccount, AccountInfo, PublicKeyInitData } from '@solana/web3.js';
import { ApiClmmPoolsItem, PoolInfoLayout, getMultipleAccountsInfoWithCustomFlags, ApiClmmPoolsItemStatistics, Currency, Token, CurrencyAmount, TokenAmount, Percent, ApiClmmConfigItem, AmmConfigLayout, ENDPOINT, Clmm, TradeV2, fetchMultipleMintInfos } from '@raydium-io/raydium-sdk';
import { config, connection, makeTxVersion, PROGRAMIDS, RAYDIUM_MAINNET_API, spinner } from '../config';
import { fetchSkipTokens, filterPools, getWalletTokenAccount, readPrivateKeysFromFile } from './utility';
import { TOKEN_2022_PROGRAM_ID, TOKEN_PROGRAM_ID } from '@solana/spl-token';
import { calculateProfit } from './profitCalculator';
import { buildAndSendTx } from './transaction';
import BN from 'bn.js';

// Define color variables
const Reset = '\x1b[0m';
const FgRed = '\x1b[31m';
const FgGreen = '\x1b[32m';
const FgBlue = '\x1b[34m';

export type TestTxInputInfo = {
    inputToken: Token | Currency;
    outputToken: Token | Currency;
    inputTokenAmount: TokenAmount | CurrencyAmount;
    slippage: Percent;

    feeConfig?: {
        feeBps: BN;
        feeAccount: PublicKey;
    };
};

export function formatConfigInfo(id: PublicKey, account: AccountInfo<Buffer>): ApiClmmConfigItem {
    const info = AmmConfigLayout.decode(account.data);
    return {
        id: id.toBase58(),
        index: info.index,
        protocolFeeRate: info.protocolFeeRate,
        tradeFeeRate: info.tradeFeeRate,
        tickSpacing: info.tickSpacing,
        fundFeeRate: info.fundFeeRate,
        fundOwner: info.fundOwner.toString(),
        description: '',
    };
}

export async function formatClmmConfigs(programId: string) {
    const configAccountInfo = await connection.getProgramAccounts(new PublicKey(programId), { filters: [{ dataSize: AmmConfigLayout.span }] });
    return configAccountInfo.map(i => formatConfigInfo(i.pubkey, i.account)).reduce((a, b) => { a[b.id] = b; return a }, {} as { [id: string]: ApiClmmConfigItem });
}

export function getApiClmmPoolsItemStatisticsDefault(): ApiClmmPoolsItemStatistics {
    return {
        volume: 0,
        volumeFee: 0,
        feeA: 0,
        feeB: 0,
        feeApr: 0,
        rewardApr: { A: 0, B: 0, C: 0 },
        apr: 0,
        priceMin: 0,
        priceMax: 0,
    };
}

export async function formatClmmKeys(programId: string, findLookupTableAddress: boolean = false): Promise<ApiClmmPoolsItem[]> {
    const filterDefKey = PublicKey.default.toString();
    const poolAccountInfo = await connection.getProgramAccounts(new PublicKey(programId), { filters: [{ dataSize: PoolInfoLayout.span }] });
    const configIdToData = await formatClmmConfigs(programId);
    const poolAccountFormat = poolAccountInfo.map(i => ({ id: i.pubkey, ...PoolInfoLayout.decode(i.account.data) }));
    const allMint = [...new Set<string>(poolAccountFormat.map(i => [i.mintA.toString(), i.mintB.toString(), ...i.rewardInfos.map(ii => ii.tokenMint.toString())]).flat())].filter(i => i !== filterDefKey).map(i => ({ pubkey: new PublicKey(i) }));
    const mintAccount = await getMultipleAccountsInfoWithCustomFlags(connection, allMint);
    const mintInfoDict = mintAccount.filter(i => i.accountInfo !== null).reduce((a, b) => { a[b.pubkey.toString()] = { programId: b.accountInfo!.owner.toString() }; return a }, {} as { [mint: string]: { programId: string } });

    const poolInfoDict = poolAccountFormat.map(i => {
        const mintProgramIdA = mintInfoDict[i.mintA.toString()].programId;
        const mintProgramIdB = mintInfoDict[i.mintB.toString()].programId;
        const rewardInfos = i.rewardInfos
            .filter(i => !i.tokenMint.equals(PublicKey.default))
            .map(i => ({
                mint: i.tokenMint.toString(),
                programId: mintInfoDict[i.tokenMint.toString()].programId,
            }));

        return {
            id: i.id.toString(),
            mintProgramIdA,
            mintProgramIdB,
            mintA: i.mintA.toString(),
            mintB: i.mintB.toString(),
            vaultA: i.vaultA.toString(),
            vaultB: i.vaultB.toString(),
            mintDecimalsA: i.mintDecimalsA,
            mintDecimalsB: i.mintDecimalsB,
            ammConfig: configIdToData[i.ammConfig.toString()],
            rewardInfos,
            tvl: 0,
            day: getApiClmmPoolsItemStatisticsDefault(),
            week: getApiClmmPoolsItemStatisticsDefault(),
            month: getApiClmmPoolsItemStatisticsDefault(),
            lookupTableAccount: PublicKey.default.toBase58(),
        };
    }).reduce((a, b) => { a[b.id] = b; return a }, {} as { [id: string]: ApiClmmPoolsItem });

    if (findLookupTableAddress) {
        const ltas = await connection.getProgramAccounts(new PublicKey('AddressLookupTab1e1111111111111111111111111'), {
            filters: [{ memcmp: { offset: 32, bytes: 'So11111111111111111111111111111111111111112' } }]
        });

        for (const itemLTA of ltas) {
            const keyStr = itemLTA.pubkey.toString();
            const ltaFormat = new AddressLookupTableAccount({
                key: itemLTA.pubkey,
                state: AddressLookupTableAccount.deserialize(itemLTA.account.data),
            });

            for (const key of ltaFormat.state.addresses) {
                const keyAddress = key.toString();
                if (poolInfoDict[keyAddress]) {
                    poolInfoDict[keyAddress].lookupTableAccount = keyStr;
                }
            }
        }
    }

    return Object.values(poolInfoDict);
}

// Fungsi untuk menyiapkan transaksi swap
export async function routeSwap(input: any) {
    const maxRetries = 5;
    const retryInterval = 1000; // dalam milidetik

    for (let attempt = 1; attempt <= maxRetries; attempt++) {
        try {
            const clmmPools = await formatClmmKeys(PROGRAMIDS.CLMM.toString());
            let sPool = await (await fetch(ENDPOINT + RAYDIUM_MAINNET_API.uiPoolInfo)).json();

            const clmmList = Object.values(await Clmm.fetchMultiplePoolInfos({
                connection,
                poolKeys: clmmPools,
                chainTime: new Date().getTime() / 1000,
            })).map((i) => i.state);

            if (clmmPools && clmmPools.length > 0 && sPool) {
                sPool.official = [];
                sPool = await filterPools(sPool);

                const getRoute = TradeV2.getAllRoute({
                    inputMint: input.inputToken instanceof Token ? input.inputToken.mint : PublicKey.default,
                    outputMint: input.outputToken instanceof Token ? input.outputToken.mint : PublicKey.default,
                    apiPoolList: sPool,
                    clmmList,
                });

                const [tickCache, poolInfosCache] = await Promise.all([
                    Clmm.fetchMultiplePoolTickArrays({ connection, poolKeys: getRoute.needTickArray, batchRequest: true }),
                    TradeV2.fetchMultipleInfo({ connection, pools: getRoute.needSimulate, batchRequest: true }),
                ]);

                spinner.start(`${FgBlue}[${Reset}Proses${FgBlue}]${Reset} Menghitung hasil dari semua rute...${Reset}`);

                const [routeInfo] = TradeV2.getAllRouteComputeAmountOut({
                    directPath: getRoute.directPath,
                    routePathDict: getRoute.routePathDict,
                    simulateCache: poolInfosCache,
                    tickCache,
                    inputTokenAmount: input.inputTokenAmount,
                    outputToken: input.outputToken,
                    slippage: input.slippage,
                    chainTime: new Date().getTime() / 1000,
                    feeConfig: input.feeConfig,
                    mintInfos: await fetchMultipleMintInfos({
                        connection,
                        mints: clmmPools
                            .map(i => [
                                { mint: i.mintA, program: i.mintProgramIdA },
                                { mint: i.mintB, program: i.mintProgramIdB }
                            ])
                            .flat()
                            .filter(i => i.program === TOKEN_2022_PROGRAM_ID.toString())
                            .map(i => new PublicKey(i.mint)),
                    }),
                    epochInfo: await connection.getEpochInfo(),
                });

                if ('middleToken' in routeInfo && routeInfo.middleToken instanceof Token) {
                    routeInfo.middleToken = new Token(
                        routeInfo.middleToken.programId,
                        new PublicKey(routeInfo.middleToken.mint),
                        routeInfo.middleToken.decimals
                    );
                }

                const tokens = await fetchSkipTokens();
                const { netProfit, middleTokenMint, priceImpact } = calculateProfit(routeInfo);

                if (tokens.includes(middleTokenMint)) {
                    spinner.fail(`${FgBlue}[${Reset}Skip${FgBlue}]${Reset} Mint: ${FgRed}${middleTokenMint}${Reset} [PI: ${FgRed}${parseFloat(priceImpact)}${Reset} % / PT: ${parseFloat(netProfit)}]${Reset}`);
                } else if (parseFloat(priceImpact) > config.priceImpactThreshold || parseFloat(netProfit) >= config.profitThreshold) {
                    spinner.succeed(`${FgBlue}[${Reset}Proses${FgBlue}]${Reset} Market: https://birdeye.so/token/${FgGreen}${middleTokenMint}${Reset}?chain=solana [PI: ${FgGreen}${parseFloat(priceImpact)}${Reset} % / PT: ${parseFloat(netProfit)}]${Reset}`);

                    const privateKeys = await readPrivateKeysFromFile('privateKeys.json');
                    let txids = [];

                    for (const privateKey of privateKeys) {
                        const wallet = Keypair.fromSecretKey(new Uint8Array(privateKey));
                        const walletTokenAccounts = await getWalletTokenAccount(connection, new PublicKey(wallet.publicKey));
                        const { innerTransactions } = await TradeV2.makeSwapInstructionSimple({
                            routeProgram: PROGRAMIDS.Router,
                            connection,
                            swapInfo: routeInfo,
                            ownerInfo: {
                                wallet: wallet.publicKey,
                                tokenAccounts: walletTokenAccounts,
                                associatedOnly: true,
                                checkCreateATAOwner: true,
                            },
                            computeBudgetConfig: {
                                units: config.units,
                                microLamports: config.microLamports,
                            },
                            makeTxVersion,
                        });

                        const txid = await buildAndSendTx(innerTransactions, wallet);

                        if (txid) {
                            txids.push(txid);
                            spinner.succeed(`${FgGreen}[complete]${Reset} Transaction ID: https://solscan.io/tx/${FgGreen}${txid}${Reset}`);
                        } else {
                            spinner.fail(`${FgRed}[${Reset}Error${FgRed}]${Reset} Transaksi gagal dikirim untuk dompet: ${wallet.publicKey.toString()}.${Reset}`);
                        }
                    }

                    return { txids };
                } else {
                    spinner.info(`${FgBlue}[${Reset}Info${FgBlue}]${Reset} Mint: ${middleTokenMint} [PI: ${FgRed}${parseFloat(priceImpact)}${Reset} % / PT: ${parseFloat(netProfit)}]${Reset}`);
                }
            }
            break; // Keluar dari loop retry jika sukses
        } catch (error) {
            console.error(`${FgRed}[${Reset}Error${FgRed}]${Reset} Terjadi kesalahan dalam menjalankan routeSwap, percobaan ${attempt}/${maxRetries}: ${error}${Reset}`);
            if (attempt < maxRetries) {
                await new Promise(resolve => setTimeout(resolve, retryInterval));
            } else {
                throw new Error(`${FgRed}[${Reset}Error${FgRed}]${Reset} Gagal menjalankan routeSwap setelah ${maxRetries} percobaan: ${(error as Error).message}`);
            }
        }
    }
}

export async function retryRouteSwap(input: TestTxInputInfo) {
    let txids: string[] = [];
    try {
        const result = await routeSwap(input);

        // Tambahkan pengecekan untuk memastikan 'result' tidak undefined
        if (result && result.txids) {
            // Menggabungkan semua array string menjadi satu array tunggal
            txids = result.txids.flat();
        } else {
            spinner.info(`${FgBlue}[${Reset}Info${FgBlue}]${Reset} Swap tidak dilakukan....${Reset}`);
        }
    } catch (error) {
        spinner.fail(`${FgRed}[${Reset}Error${FgRed}] ${(error as Error).message}${Reset}`);
    }
    return txids;
}

export async function swapTokenToSol(amountToken: string | number, mint: PublicKeyInitData, decimals: number, outMint: PublicKeyInitData, outDecimal: number) {
    try {
        const outputToken = new Token(TOKEN_PROGRAM_ID, new PublicKey(outMint), outDecimal);
        const inputToken = new Token(TOKEN_PROGRAM_ID, new PublicKey(mint), decimals);

        const inputAmountInSOL: string | number = amountToken;

        if (inputAmountInSOL !== null) {
            const inputTokenAmount = new (inputToken instanceof Token ? TokenAmount : CurrencyAmount)(
                inputToken,
                inputAmountInSOL
            );

            const slippage = config.slippage;

            const result = await retryRouteSwap({
                inputToken,
                outputToken,
                inputTokenAmount,
                slippage,
            });
            // Jika result adalah void, berikan pesan ke pengguna
            if (result === undefined) {
                spinner.info(`${FgBlue}[${Reset}Info${FgBlue}]${Reset} Swap tidak dilakukan....${Reset}`);
                return;
            }
        } else {
            spinner.fail(`${FgRed}[${Reset}Error${FgRed}]${Reset} ${FgRed}inputAmountInSOL is null.${Reset}`);
        }
    } catch (error) {
        spinner.fail(`${FgRed}[${Reset}Error${FgRed}] ${(error as Error).message}${Reset}`);
    }
}