import { LAMPORTS_PER_SOL } from '@solana/web3.js';
import { config, spinner } from '../config';
import { swapTokenToSol } from './RouteSwap';

// Define color variables
const Reset = '\x1b[0m';
const FgRed = '\x1b[31m';
const FgBlue = '\x1b[34m';

async function fetchData() {
    while (true) {
        try {
            for (let amount of config.amounts) { // Loop melalui setiap elemen dalam array
                let parsedAmount = parseFloat(amount); // Mengonversi elemen menjadi angka
                spinner.info(`\n${FgBlue}[${Reset}Info${FgBlue}]${Reset} Amount: [ ${parsedAmount} $SOL ]${Reset}`);
                await swapTokenToSol(parsedAmount * LAMPORTS_PER_SOL, config.outMint, config.outDecimal, config.outMint, config.outDecimal);
            }
        } catch (error) {
            spinner.fail(`${FgRed}[${Reset}Error${FgRed}] ${(error as Error).message}${Reset}`);
        }
    }
}

// Start the loop
fetchData();
