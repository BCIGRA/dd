import BN from 'bn.js';
import { ComputeAmountOutAmmLayout, ComputeAmountOutRouteLayout } from '@raydium-io/raydium-sdk';

export function calculateProfit(routeInfo: ComputeAmountOutAmmLayout | ComputeAmountOutRouteLayout) {
    // Calculate price impact percentage
    const priceImpactNumerator = new BN(routeInfo.priceImpact.numerator, 16);
    const priceImpactDenominator = new BN(routeInfo.priceImpact.denominator, 16);
    const priceImpactFraction = priceImpactNumerator
        .mul(new BN(100)) // multiply by 100 to convert to percentage
        .div(priceImpactDenominator);

    // Convert price impact percentage to decimal string
    const priceImpactPercent = (priceImpactFraction.toNumber() / 100).toFixed(2);

    // Parse data into BN (Big Number) format
    const amountInNumerator = new BN(routeInfo.amountIn.amount.numerator, 16);
    const amountInDenominator = new BN(routeInfo.amountIn.amount.denominator, 16);

    const amountOutNumerator = new BN(routeInfo.amountOut.amount.numerator, 16);
    const amountOutDenominator = new BN(routeInfo.amountOut.amount.denominator, 16);

    const fee1Numerator = new BN(routeInfo.fee[0].numerator, 16);
    const fee1Denominator = new BN(routeInfo.fee[0].denominator, 16);

    const fee2Numerator = new BN(routeInfo.fee[1].numerator, 16);
    const fee2Denominator = new BN(routeInfo.fee[1].denominator, 16);

    // Calculate amount of tokens bought and received
    const amountInBN = amountInNumerator.mul(new BN(10).pow(new BN(18))).div(amountInDenominator);
    const amountOutBN = amountOutNumerator.mul(new BN(10).pow(new BN(18))).div(amountOutDenominator);

    // Calculate profit
    const profit = amountOutBN.sub(amountInBN);

    // Calculate total fees
    const totalFee = fee1Numerator.mul(new BN(10).pow(new BN(18))).div(fee1Denominator)
        .add(fee2Numerator.mul(new BN(10).pow(new BN(18))).div(fee2Denominator));

    // Calculate net profit
    let netProfit = profit.sub(totalFee);

    let middleTokenMint = '';

    if ('middleToken' in routeInfo) {
        // Jika objek adalah ComputeAmountOutRouteLayout
        middleTokenMint = routeInfo.middleToken?.mint.toString();;
    }

    // Check if net profit is not zero
    if (netProfit.isZero()) {
        return {
            netProfit: '0',
            middleTokenMint: '',
            priceImpact: priceImpactPercent,
        };
    }

    // Convert net profit to decimal string
    const netProfitStr = (parseFloat(new BN(netProfit).toString()) / 1e18).toFixed(9);

    // Return net profit
    return {
        netProfit: netProfitStr,
        middleTokenMint: middleTokenMint,
        priceImpact: priceImpactPercent,
    };
}
