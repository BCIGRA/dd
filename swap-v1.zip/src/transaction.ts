import {
    Connection,
    Keypair,
    SendOptions,
    Signer,
    Transaction,
    VersionedTransaction
} from '@solana/web3.js';
import { connection, makeTxVersion, addLookupTableInfo, spinner, API_ENDPOINT } from '../config';
import { buildSimpleTransaction, InnerSimpleV0Transaction } from '@raydium-io/raydium-sdk';

const Reset = '\x1b[0m';
const FgRed = '\x1b[31m';
const FgBlue = '\x1b[34m';

export async function sendTx(
    payer: Keypair | Signer,
    txs: (VersionedTransaction | Transaction)[],
    options?: SendOptions
): Promise<string[]> {
    const connections = new Connection(API_ENDPOINT, { commitment: 'finalized' });

    const enhancedOptions = { ...options, skipPreflight: true, maxRetries: 6 };

    const txPromises = txs.map(async (iTx) => {
        if (iTx instanceof VersionedTransaction) {
            return sendVersionedTransaction(iTx, connections, payer, enhancedOptions);
        } else {
            return sendStandardTransaction(iTx, connections, payer, enhancedOptions);
        }
    });

    return Promise.all(txPromises);
}

async function sendVersionedTransaction(
    iTx: VersionedTransaction,
    connections: Connection,
    payer: Keypair | Signer,
    options: SendOptions
): Promise<string> {
    try {
        iTx.sign([payer]);
        iTx.serialize();
        await connections.simulateTransaction(iTx);
        spinner.info(`${FgBlue}[${Reset}Proses${FgBlue}]${Reset} Proses Menggunakan skipPreflight dan VersionedTransaction`);
        return connections.sendTransaction(iTx, options);
    } catch (error) {
        spinner.fail(`${FgRed}[${Reset}Error${FgRed}]${Reset} Error Gagal mengirim VersionedTransaction: ${error}`);
        throw error;
    }
}

async function sendStandardTransaction(
    iTx: Transaction,
    connections: Connection,
    payer: Keypair | Signer,
    options: SendOptions
): Promise<string> {
    try {
        await connections.simulateTransaction(iTx, [payer]);
        spinner.info(`${FgBlue}[${Reset}Proses${FgBlue}]${Reset} Proses Menggunakan skipPreflight true`);
        return connections.sendTransaction(iTx, [payer], options);
    } catch (error) {
        spinner.fail(`${FgRed}[${Reset}Error${FgRed}]${Reset} Error Gagal mengirim StandardTransaction: ${error}`);
        throw error;
    }
}

export async function buildAndSendTx(
    innerSimpleV0Transactions: InnerSimpleV0Transaction[],
    wallet: any
): Promise<string[] | null> {
    try {
        // Mendapatkan blockhash terbaru
        const recentBlockhash = await connection.getLatestBlockhashAndContext();

        // Membangun transaksi
        const transactions = await Promise.all(innerSimpleV0Transactions.map(async (innerTx) => {
            const willSendTx = await buildSimpleTransaction({
                connection,
                makeTxVersion,
                payer: wallet.publicKey,
                innerTransactions: [innerTx],
                recentBlockhash: recentBlockhash.value.blockhash,
                addLookupTableInfo: addLookupTableInfo,
            });
            return willSendTx[0]; // Mengambil elemen pertama dari array
        }));

        // Mengirim transaksi secara paralel
        const txids = await sendTx(wallet, transactions);
        return txids;
    } catch (error) {
        spinner.fail(`${FgRed}[${Reset}Error${FgRed}]${Reset} Gagal mengirim TXID: ${error}`);
        return null;
    }
}
