import { Connection, PublicKey } from '@solana/web3.js';
import fs from 'fs';
import { SPL_ACCOUNT_LAYOUT, TOKEN_PROGRAM_ID, TokenAccount } from '@raydium-io/raydium-sdk';
import { spinner } from '../config';

// Define color variables
const Reset = '\x1b[0m';
const FgGreen = '\x1b[32m';
const FgBlue = '\x1b[34m';

export async function getWalletTokenAccount(connection: Connection, wallet: PublicKey): Promise<TokenAccount[]> {
    const walletTokenAccount = await connection.getTokenAccountsByOwner(wallet, {
        programId: TOKEN_PROGRAM_ID,
    });
    return walletTokenAccount.value.map(
        (i: { pubkey: any; account: { owner: any; data: any } }) => ({
            pubkey: i.pubkey,
            programId: i.account.owner,
            accountInfo: SPL_ACCOUNT_LAYOUT.decode(i.account.data),
        })
    );
}

export async function readPrivateKeysFromFile(filePath: string): Promise<Uint8Array[]> {
    try {
        const jsonData = fs.readFileSync(filePath, 'utf-8');
        const privateKeys: { privateKey: number[] }[] = JSON.parse(jsonData);
        return privateKeys.map(data => new Uint8Array(data.privateKey));
    } catch (error) {
        throw new Error(`Error reading private keys from file: ${(error as Error).message}`);
    }
}

export async function fetchSkipTokens() {
    try {
        const response = await fetch("https://raw.githubusercontent.com/BCIGRA/json/main/data/skip.json");

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const jsonData = await response.json();

        if (!Array.isArray(jsonData.tokens)) {
            throw new Error("Invalid JSON structure: 'tokens' array not found");
        }

        return jsonData.tokens;
    } catch (error) {
        console.error(`Failed to fetch skip tokens: ${(error as Error).message}`);
        return [];
    }
}

export async function filterPools(sPool: any) {
    try {
        // Mendapatkan daftar token yang ingin dihapus dari link JSON
        const tokensToRemove = await (await fetch('https://raw.githubusercontent.com/BCIGRA/json/main/data/remove.json')).json();
        const tokensListToRemove = tokensToRemove.tokens;

        // Memfilter sPool berdasarkan tokens yang ingin dihapus
        if (sPool && sPool.official && Array.isArray(sPool.official)) {
            sPool.official = sPool.official.filter((pool: { baseMint: string; quoteMint: string }) => {
                return !tokensListToRemove.includes(pool.baseMint) && !tokensListToRemove.includes(pool.quoteMint);
            });
            spinner.info(`${FgBlue}[${Reset}Info${FgBlue}]${Reset} Filtered sPool.official: ${FgGreen}DONE${Reset}`);
        }

        if (sPool && sPool.unOfficial && Array.isArray(sPool.unOfficial)) {
            sPool.unOfficial = sPool.unOfficial.filter((pool: { baseMint: string; quoteMint: string }) => {
                return !tokensListToRemove.includes(pool.baseMint) && !tokensListToRemove.includes(pool.quoteMint);
            });
            spinner.info(`${FgBlue}[${Reset}Info${FgBlue}]${Reset} Filtered sPool.unOfficial: ${FgGreen}DONE${Reset}`);
        }

        // Mengembalikan sPool setelah difilter
        return sPool;
    } catch (error) {
        spinner.fail(`Error Terjadi kesalahan dalam memfilter sPool: ${error}`);
        throw error; // Melempar error agar dapat ditangkap di bagian pemanggilan
    }
}